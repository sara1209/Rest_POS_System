// src/app/features/tables/tables.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

interface TableCard {
  number: number;
  status: 'booked' | 'available';
  label: 'WB' | 'N/A';
  labelColor?: 'blue' | 'red' | 'green';
}

@Component({
  selector: 'app-tables',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './tables.html',
  styleUrls: ['./tables.css']
})
export class Tables {

  tables: TableCard[] = [
    { number: 1, status: 'booked', label: 'WB', labelColor: 'blue' },
    { number: 2, status: 'booked', label: 'WB', labelColor: 'red' },
    { number: 3, status: 'booked', label: 'WB', labelColor: 'green' },
    { number: 4, status: 'available', label: 'N/A' },
    { number: 5, status: 'available', label: 'N/A' },
    { number: 6, status: 'booked', label: 'WB', labelColor: 'blue' },
    { number: 7, status: 'booked', label: 'WB', labelColor: 'blue' },
    { number: 8, status: 'available', label: 'N/A' },
    { number: 9, status: 'available', label: 'N/A' },
  ];

  getCircleClass(table: TableCard): string {
    if (table.label === 'WB' && table.labelColor) {
      return table.labelColor;
    }
    return '';
  }
}