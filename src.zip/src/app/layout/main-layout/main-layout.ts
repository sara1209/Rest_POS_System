import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Header } from '../../shared/header/header';
import { BottomNav } from '../../shared/bottom-nav/bottom-nav';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [RouterOutlet, Header, BottomNav],
  template: `
    <div class="layout-wrapper">

      <app-header></app-header>

      <div class="page-content">
        <router-outlet></router-outlet>
      </div>

      <app-bottom-nav></app-bottom-nav>

    </div>
  `,
  styles: [`
  .layout-wrapper {
    display: flex;
    flex-direction: column;
    min-height: 100vh;
  }

  .page-content {
    flex: 1 1 auto;
    /* padding-bottom should match or be slightly bigger than bottom-nav height */
    padding-bottom: 70px; 
    overflow-y: auto;
  }

  /* Optional: force bottom nav to stay at bottom even with little content */
  app-bottom-nav {
    flex-shrink: 0;
  }
`]
})
export class MainLayout {}
